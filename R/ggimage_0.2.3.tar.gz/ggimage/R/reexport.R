##' @importFrom ggplotify as.grob
##' @export
ggplotify::as.grob

##' @importFrom ggplotify as.ggplot
##' @export
ggplotify::as.ggplot
